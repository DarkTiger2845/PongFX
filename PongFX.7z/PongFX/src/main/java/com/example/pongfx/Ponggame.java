package com.example.pongfx;

import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.*;
import javafx.scene.input.KeyCode;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;



public class Ponggame extends Application{


    boolean game = true;
    boolean round;

    //Score Tracker
    private int scoreplayerone = 0;
    private int scoreplayertwo = 0;

    // window scaling
    private static final int width = 800;
    private static final int height = 600;

    // positioning of the players
    private double Xpositionplayerone = 0;
    private double Xpositionplayertwo = width - Recwidth;
    // Y-Positioning
    private double Ypositionplayerone = height/2;
    private double Ypositionplayertwo = height/2;

    // player / ball sizing
    public static final int Recheight = 80;
    public static final int Recwidth = 10;

    public static final double ballradiant = 10;

    Canvas canvas = new Canvas(width, height);



 // Positioning of the Ball in the beginning
    private double Xpositionball = width/2;
    private double Ypositionball = height/2;
    //Ball speed
    private int Yspeedball = 1;
    private int Xspeedball = 1;



    @Override
    public void start(Stage stage) throws IOException {
        stage.setTitle("Pong - The Game (Computer Graphics 2D Project)");

        GraphicsContext gc = canvas.getGraphicsContext2D();

        canvas.setOnMouseClicked(e -> round = true);


         // created the game loop with that : https://stackoverflow.com/questions/59020064/use-timeline-keyframes-with-javafx-within-a-for-loop
        // Tried with animation timer but had problems with using it.

            Timeline timeline = new Timeline(new KeyFrame(Duration.millis(10), e -> gameloop(gc)));
            timeline.setCycleCount(Timeline.INDEFINITE);



        // probably the cheesy way to get the players controlls , tried a lot which didnt work so i went with a cheesy way
        Button btn = new Button();
        btn.setOpacity(0);



        btn.setOnKeyPressed(new EventHandler<KeyEvent>() {

            @Override
            public void handle(KeyEvent keyEvent) {

                switch (keyEvent.getCode()){

                       // controls p1
                    case W: Ypositionplayerone -= 20; break;
                    case A: Xpositionplayerone -= 40; break;
                    case S: Ypositionplayerone += 20; break;
                    case D: Xpositionplayerone += 40; break;

                    //controls p2
                    case UP:  Ypositionplayertwo -= 20; break;
                    case DOWN: Ypositionplayertwo += 20; break;
                    case LEFT: Xpositionplayertwo -= 40; break;
                    case RIGHT:  Xpositionplayertwo += 40; break;

                    default: break;

                }
            }
        });






        Scene scene = new Scene(new StackPane(canvas,btn));
        stage.setScene(scene);
        stage.show();
        timeline.play();
    }




        private void gameloop(GraphicsContext gc){
        int earlyscore1 = 0;
        int earlyscore2 = 0;

 // setting background everytime  is absolutly needed if not there it will just draw lines
            gc.setFill(Color.BLACK);
            gc.fillRect(0, 0, width, height);

            gc.setFill(Color.RED);
            gc.setFont(Font.font(25));

            if(round && game) {
                // Ball moving and creation
                Xpositionball += Xspeedball;
                Ypositionball += Yspeedball;
                gc.fillOval(Xpositionball, Ypositionball, ballradiant, ballradiant);


            } else {

                if((scoreplayerone != earlyscore1 )|| scoreplayertwo != earlyscore2) {
                    earlyscore1 = scoreplayerone;
                    earlyscore2 = scoreplayertwo;
                    Xpositionball = width / 2;
                    Ypositionball = height / 2;

                    if (scoreplayerone == 5 || scoreplayertwo == 5) {
                        String winner;
                        if(scoreplayerone<scoreplayertwo)  winner = "PLayer 2";
                        else winner = "Player 1";
                        gc.fillText("Winner: " + winner,width/2 - 50,height/2);
                        game = false;
                    }
                }
                //reset
             if(!game && round){
                 scoreplayertwo = 0;
                 scoreplayerone = 0;
                 game = true;
             }
            }





             // checks if the ball hit the Players surroundings ( if hit ball should bounce into other direction)
            if((Xpositionball + ballradiant > Xpositionplayertwo && (Ypositionball >= Ypositionplayertwo && Ypositionball <= Ypositionplayertwo + Recheight)  ) || (Xpositionball < Xpositionplayerone + Recwidth && (Ypositionball >= Ypositionplayerone && Ypositionball <= Ypositionplayertwo + Recheight))){
                Xspeedball *= -1;
                Yspeedball *= -1;
            }





            // When ever the player goes over the middle it should reset the player to his standard position
            if(Xpositionplayerone > width/2 - 1) Xpositionplayerone = 0;
            if(Xpositionplayertwo < width/2 + 1) Xpositionplayertwo = width - Recwidth;

            //should save the player from going outside the border aswell
            if(Xpositionplayerone < 0) Xpositionplayerone = 5;
            if(Xpositionplayertwo > width) Xpositionplayertwo = width-5;

            if(Ypositionplayerone + Recheight > height || Ypositionplayerone  < 0)  Ypositionplayerone = height/2;
            if(Ypositionplayertwo + Recheight >height || Ypositionplayertwo  < 0 )  Ypositionplayertwo = height/2;



            // turning direction of the ball so he wont leave :D
            if (Ypositionball > height || Ypositionball < 0) Yspeedball *= -1;

            //scoring
            if (Xpositionball < Xpositionplayerone && Xpositionball < 5) {
                scoreplayertwo++;
                round = false;
            }
            if (Xpositionball > Xpositionplayertwo && Xpositionball >= width-5) {
                scoreplayerone++;
                round = false;
            }


            //Draws the score and the players
            gc.fillText(scoreplayerone +  " Points "+ scoreplayertwo, width /2 - 50, 250);
            gc.fillRect(Xpositionplayerone, Ypositionplayerone, Recwidth, Recheight);
            gc.fillRect(Xpositionplayertwo, Ypositionplayertwo, Recwidth, Recheight);




        }


    public static void main(String[] args) {
        launch();
    }
}


